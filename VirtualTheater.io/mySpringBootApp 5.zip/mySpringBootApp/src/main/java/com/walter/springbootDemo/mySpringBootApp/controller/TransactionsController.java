package com.walter.springbootDemo.mySpringBootApp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.Transactions;
import com.walter.springbootDemo.mySpringBootApp.repository.TransactionsRepository;

@RestController
@RequestMapping("/walter_api/v3")
public class TransactionsController {
	
	@Autowired
	private TransactionsRepository transactionsRepository;

	@GetMapping("/transactions")
	public List<Transactions> getAllTransactions(){
		return transactionsRepository.findAll();
	}
	
	@GetMapping("/transactions/{id}")
	public ResponseEntity<Transactions> getTransactionsById(@PathVariable(value = "id") Long transactionsId)
	 throws ResourceNotFoundException {
		Transactions transactions = transactionsRepository.findById(transactionsId)
				.orElseThrow(() -> new ResourceNotFoundException("Transactions not found for this id ::"
						+transactionsId));
		return ResponseEntity.ok().body(transactions);
	}
	
	
	@PostMapping("/transactions")
	public Transactions createTransactions(@Valid @RequestBody Transactions transactions) {
		return transactionsRepository.save(transactions);
	}
	//Update Transactions
	@PutMapping("/transactions/{id}")
	public ResponseEntity<Transactions> updateTransactionsById(@PathVariable(value = "id") Long transactionsId, @Valid @RequestBody Transactions transactionsDetails)
			 throws ResourceNotFoundException {
		Transactions transactions = transactionsRepository.findById(transactionsId)
						.orElseThrow(() -> new ResourceNotFoundException("Transactions not found for this id ::"
								+transactionsId));
				//return ResponseEntity.ok().body(employee);
		transactions.setUserId(transactionsDetails.getUserId());
		transactions.setMovieId(transactionsDetails.getMovieId());
		transactions.setDate(transactionsDetails.getDate());
		transactions.setTitle(transactionsDetails.getTitle());
		transactions.setImage(transactionsDetails.getImage());
		transactions.setPrice(transactionsDetails.getPrice());
				
				final Transactions updatedTransactions = transactionsRepository.save(transactions);
				return ResponseEntity.ok(updatedTransactions);
			}
	
	//Delete Transactions
	
	@DeleteMapping("/transactions/{id}")
	public Map<String, Boolean> deletedTransactions(@PathVariable(value = "id") Long transactionsId)
			 throws ResourceNotFoundException {
		Transactions transactions = transactionsRepository.findById(transactionsId)
						.orElseThrow(() -> new ResourceNotFoundException("Transactions not found for this id ::"
								+transactionsId));
		transactionsRepository.delete(transactions);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}
