package com.walter.springbootDemo.mySpringBootApp.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.Ingredient;
import com.walter.springbootDemo.mySpringBootApp.repository.IngredientRepository;

@RestController
@RequestMapping("/walter_api/v2")
public class IngredientController {
	
	@Autowired
	private IngredientRepository ingredientRepository;
	@GetMapping("/ingredients")
	public List<Ingredient> getAllIngredients(){
		return ingredientRepository.findAll();
	}
	
	@GetMapping("/ingredients/{id}")
	public ResponseEntity<Ingredient> getUserById(@PathVariable(value = "id") Long ingredientId)
	 throws ResourceNotFoundException {
		Ingredient ingredient = ingredientRepository.findById(ingredientId)
				.orElseThrow(() -> new ResourceNotFoundException("Ingredient not found for this id ::"
						+ingredientId));
		return ResponseEntity.ok().body(ingredient);
	}
	
	
	@PostMapping("/ingredients")
	public Ingredient createIngredient(@Valid @RequestBody Ingredient ingredient) {
		return ingredientRepository.save(ingredient);
	}
	
	@PutMapping("/ingredients/{id}")
	public ResponseEntity<Ingredient> updateIngredientById(@PathVariable(value = "id") Long ingredientId, @Valid @RequestBody Ingredient ingredientDetails)
			 throws ResourceNotFoundException {
		Ingredient ingredient = ingredientRepository.findById(ingredientId)
						.orElseThrow(() -> new ResourceNotFoundException("Ingredient not found for this id ::"
								+ingredientId));
				//return ResponseEntity.ok().body(employee);
		ingredient.setAmount(ingredientDetails.getAmount());
		ingredient.setImage(ingredientDetails.getImage());
		ingredient.setName(ingredientDetails.getName());
		ingredient.setUserId(ingredientDetails.getUserId());
		ingredient.setUnit(ingredientDetails.getUnit());
				
				final Ingredient updatedIngredient = ingredientRepository.save(ingredient);
				return ResponseEntity.ok(updatedIngredient);
			}
	
	
	
	@DeleteMapping("/ingredients/{id}")
	public Map<String, Boolean> deletedIngredient(@PathVariable(value = "id") Long ingredientId)
			 throws ResourceNotFoundException {
		Ingredient ingredient = ingredientRepository.findById(ingredientId)
						.orElseThrow(() -> new ResourceNotFoundException("Ingredient not found for this id ::"
								+ingredientId));
		ingredientRepository.delete(ingredient);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}
