package com.walter.springbootDemo.mySpringBootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
