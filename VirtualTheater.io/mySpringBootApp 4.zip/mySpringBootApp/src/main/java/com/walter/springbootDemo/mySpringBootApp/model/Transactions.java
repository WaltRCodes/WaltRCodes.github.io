package com.walter.springbootDemo.mySpringBootApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transactions")
public class Transactions {

	
	private long id;
	private long user_id;
	private String title;
	private String date;
	private String image;
	private long price;
	
	public Transactions() {
		
	}
	
	public Transactions(long user_id, String title, String date, String image, long price) {
		super();
		this.user_id = user_id;
		this.title = title;
		this.date = date;
		this.image = image;
		this.price = price;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name="user_id")
	public long getUserId() {
			return user_id;
	}
	
	public void setUserId(long user_id) {
		this.user_id = user_id;
	}
	
	@Column(name="title")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	@Column(name="date")
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	@Column(name="image")
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	@Column(name="price")
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	
	
	
}

