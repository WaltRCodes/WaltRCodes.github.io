package com.walter.springbootDemo.mySpringBootApp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.Account;
import com.walter.springbootDemo.mySpringBootApp.repository.AccountRepository;

@RestController
@RequestMapping("/walter_api/v3")
public class AccountController {
	
	@Autowired
	private AccountRepository accountRepository;
	//get all employees
	@GetMapping("/accounts")
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}
	// get all employees by id
	@GetMapping("/accounts/{id}")
	public ResponseEntity<Account> getAccountById(@PathVariable(value = "id") Long accountId)
	 throws ResourceNotFoundException {
		Account account = accountRepository.findById(accountId)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found for this id ::"
						+accountId));
		return ResponseEntity.ok().body(account);
	}
	
	// save employee
	@PostMapping("/accounts")
	public Account createAccount(@Valid @RequestBody Account account) {
		return accountRepository.save(account);
	}
	//Update Employee
	@PutMapping("/accounts/{id}")
	public ResponseEntity<Account> updateAccountById(@PathVariable(value = "id") Long accountId, @Valid @RequestBody Account accountDetails)
			 throws ResourceNotFoundException {
		Account account = accountRepository.findById(accountId)
						.orElseThrow(() -> new ResourceNotFoundException("Account not found for this id ::"
								+accountId));
				//return ResponseEntity.ok().body(employee);
		account.setPassword(accountDetails.getPassword());
		account.setName(accountDetails.getName());
		account.setEmail(accountDetails.getEmail());
		account.setBalance(accountDetails.getBalance());
		account.setAddress(accountDetails.getAddress());
				
				final Account updatedAccount = accountRepository.save(account);
				return ResponseEntity.ok(updatedAccount);
			}
	
	//Delete Employee
	
	@DeleteMapping("/accounts/{id}")
	public Map<String, Boolean> deletedAccount(@PathVariable(value = "id") Long accountId)
			 throws ResourceNotFoundException {
		Account account = accountRepository.findById(accountId)
						.orElseThrow(() -> new ResourceNotFoundException("Account not found for this id ::"
								+accountId));
		accountRepository.delete(account);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}
