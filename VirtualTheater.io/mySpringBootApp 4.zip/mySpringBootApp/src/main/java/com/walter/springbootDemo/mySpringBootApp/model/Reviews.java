package com.walter.springbootDemo.mySpringBootApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reviews")
public class Reviews {

	
	
	private long id;
	private long user_id;
	private String description;
	private String date;
	private long movie_id;
	private long rating;
	
	
	public Reviews() {
		
	}
	
	
	public Reviews(long user_id, String description, String date, long movie_id, long rating) {
		super();
		this.user_id = user_id;
		this.description = description;
		this.date = date;
		this.movie_id = movie_id;
		this.rating = rating;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name="user_id")
	public long getUserId() {
			return user_id;
	}
	
	public void setUserId(long user_id) {
		this.user_id = user_id;
	}
	
	@Column(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name="date")
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	@Column(name="movie_id")
	public long getMovieId() {
		return movie_id;
	}
	public void setMovieId(long movie_id) {
		this.movie_id = movie_id;
	}
	
	@Column(name="rating")
	public long getRating() {
		return rating;
	}
	public void setRating(long rating) {
		this.rating = rating;
	}
	
	
	
}

