package com.walter.springbootDemo.mySpringBootApp.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walter.springbootDemo.mySpringBootApp.exception.ResourceNotFoundException;
import com.walter.springbootDemo.mySpringBootApp.model.Reviews;
import com.walter.springbootDemo.mySpringBootApp.repository.ReviewsRepository;

@RestController
@RequestMapping("/walter_api/v3")
public class ReviewsController {
	
	@Autowired
	private ReviewsRepository reviewsRepository;

	@GetMapping("/reviews")
	public List<Reviews> getAllReviews(){
		return reviewsRepository.findAll();
	}
	
	@GetMapping("/reviews/{id}")
	public ResponseEntity<Reviews> getReviewsById(@PathVariable(value = "id") Long reviewsId)
	 throws ResourceNotFoundException {
		Reviews reviews = reviewsRepository.findById(reviewsId)
				.orElseThrow(() -> new ResourceNotFoundException("Reviews not found for this id ::"
						+reviewsId));
		return ResponseEntity.ok().body(reviews);
	}
	
	
	@PostMapping("/reviews")
	public Reviews createReviews(@Valid @RequestBody Reviews reviews) {
		return reviewsRepository.save(reviews);
	}
	//Update Transactions
	@PutMapping("/reviews/{id}")
	public ResponseEntity<Reviews> updateTransactionsById(@PathVariable(value = "id") Long reviewsId, @Valid @RequestBody Reviews reviewsDetails)
			 throws ResourceNotFoundException {
		Reviews reviews = reviewsRepository.findById(reviewsId)
						.orElseThrow(() -> new ResourceNotFoundException("Reviews not found for this id ::"
								+reviewsId));
				//return ResponseEntity.ok().body(employee);
		reviews.setUserId(reviewsDetails.getUserId());
		reviews.setDate(reviewsDetails.getDate());
		reviews.setMovieId(reviewsDetails.getMovieId());
		reviews.setDescription(reviewsDetails.getDescription());
		reviews.setRating(reviewsDetails.getRating());
				
				final Reviews updatedReviews = reviewsRepository.save(reviews);
				return ResponseEntity.ok(updatedReviews);
			}
	
	//Delete Transactions
	
	@DeleteMapping("/reviews/{id}")
	public Map<String, Boolean> deletedReviews(@PathVariable(value = "id") Long reviewsId)
			 throws ResourceNotFoundException {
		Reviews reviews = reviewsRepository.findById(reviewsId)
						.orElseThrow(() -> new ResourceNotFoundException("Reviews not found for this id ::"
								+reviewsId));
		reviewsRepository.delete(reviews);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted users", Boolean.TRUE);
				
				return response;
		
	}
}

