package com.walter.springbootDemo.mySpringBootApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ingredients")
public class Ingredient {

	
	private long id;
	private long user_id;
	private String name;
	private int amount;
	private String image;
	private String unit;
	
	public Ingredient() {
		
	}
	
	public Ingredient(long user_id, String name, int amount, String image, String unit) {
		super();
		this.user_id = user_id;
		this.name = name;
		this.amount = amount;
		this.image = image;
		this.unit = unit;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name="user_id")
	public long getUserId() {
			return user_id;
	}
	
	public void setUserId(long user_id) {
		this.user_id = user_id;
	}
	
	@Column(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name="amount")
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	@Column(name="image")
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	@Column(name="unit")
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	
	
	
	
}
